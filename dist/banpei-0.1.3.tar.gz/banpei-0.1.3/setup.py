# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['banpei', 'banpei.base']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.19.2,<2.0.0', 'pandas>=1.1.2,<2.0.0', 'scipy>=1.5.2,<2.0.0']

setup_kwargs = {
    'name': 'banpei',
    'version': '0.1.3',
    'description': 'Anomaly detection library with Python',
    'long_description': None,
    'author': 'Hirofumi Tsuruta',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
